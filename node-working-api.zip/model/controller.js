// const { getUsers } = require("./router");

const { hashSync, genSaltSync, compareSync, } = require("bcrypt");
const { sign } = require("jsonwebtoken");
var bcrypt = require('bcrypt');

const {
    getUsers,
    getUserByUserEmail,
    getsingleUsers,
} = require("./service");

module.exports = {
    getUsers: (req, res) => {
        getUsers((err, results) => {
            if (err) {
                console.log(err);
                return;
            }
            return res.json({
                success: 1,
                data: results
            });
        });
    },
    login: (req, res) => {
        const body = req.body;
        // console.log(body.Email);
        getUserByUserEmail(body.Email, (err, results) => {
            if (err) {
                console.log(err);
            }
            if (!results) {
                return res.json({
                    success: 0,
                    data: "Invalid email or password"
                });
            }
          
            // console.log(body.password, "body");
            // console.log(results.password, "resultpwd");

            const result = bcrypt.compare(body.password, results.password);
            if (result) {
                // results.password = undefined;
                const jsontoken = sign({ result: results }, "qwe1234", {
                    expiresIn: "1h"
                });
                console.log("dvrrrfrrf");

                return res.json({
                    success: 1,
                    message: "login successfull",
                    token: jsontoken
                });

            } else {
                return res.json({
                    success: 0,
                    data: "Invalid email or password"
                });
            }
        });
    },
    getsingleUsers: (req, res) => {
        const id = req.params.id;
        getsingleUsers(id, (err, results) => {
            if (err) {
                console.log(err);
                return;
            }
            if (!results) {
                return res.json({
                    success: 0,
                    message: "Record not Found"
                });
            }
            results.password = undefined;
            return res.json({
                success: 1,
                data: results
            });
        });
    }
}; 